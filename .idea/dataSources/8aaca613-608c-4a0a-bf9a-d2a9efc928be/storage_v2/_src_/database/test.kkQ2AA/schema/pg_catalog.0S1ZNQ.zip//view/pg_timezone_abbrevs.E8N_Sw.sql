create view pg_timezone_abbrevs(abbrev, utc_offset, is_dst) as
SELECT pg_timezone_abbrevs.abbrev,
       pg_timezone_abbrevs.utc_offset,
       pg_timezone_abbrevs.is_dst
FROM pg_timezone_abbrevs() pg_timezone_abbrevs(abbrev, utc_offset, is_dst);

alter table pg_timezone_abbrevs
    owner to obaidaqeel;

grant select on pg_timezone_abbrevs to public;

